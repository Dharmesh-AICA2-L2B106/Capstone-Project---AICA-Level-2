DEPLOYMENT NOTES
1. Files: assignment_tracker_eod_portal.py, requirements.txt, Procfile, render.yaml
2. Push these files to a private GitHub repository.
3. Render: New > Blueprint > pick the repo. Enter ADMIN_EMAIL and a STRONG ADMIN_PASSWORD when asked.
   The persistent disk keeps eod_portal.db across restarts (disks need a paid instance; check current Render plans).
   Without a persistent disk the SQLite file is wiped on every redeploy/restart.
4. Keep workers at 1 (SQLite). Back up the database file regularly.
5. Local test of production server (Linux/Mac): pip install -r requirements.txt && gunicorn assignment_tracker_eod_portal:app
   On Windows use: pip install waitress && waitress-serve --port=5000 assignment_tracker_eod_portal:app
