VALUATIONPILOT - how to run (Windows)

1. Install Python 3.10 or newer from https://www.python.org/downloads/
   (tick "Add python.exe to PATH" during installation). Only needed once.
2. Keep this folder anywhere, for example on the Desktop.
3. Double-click Start_ValuationPilot.bat
   - The first run installs the packages (internet needed once, about a minute).
   - ValuationPilot then opens in its own application window. There is no browser,
     no address bar and no black window. Close the window (or click Exit) to quit.
4. Optional: double-click Create_Desktop_Shortcut.bat once. It puts a ValuationPilot
   icon on your Desktop. Right-click the icon and choose Pin to taskbar if you like.
5. Work through the tabs: Inputs, Industry, Growth plan, Valuation, Report.
6. On the Report tab, click Generate, then Open Word report or Open Excel workbook.
   The files are also saved in the "output" folder.

IF IT DOES NOT OPEN
  Double-click Start_ValuationPilot_Debug.bat. It shows any error message in a window.
  The file valuationpilot.log in this folder also records what went wrong.
  If the application window is not available on a PC, the app uses an Edge or Chrome
  window without tabs or address bar, and as a last resort a browser tab (use the Exit
  button to close it).

UPDATING FROM AN EARLIER VERSION
  Copy the new files over the old ones, close the app if it is open, and start the
  .bat file again (the first start after an update installs one extra package). Your saved industries (industries.json) are kept; new industries
  are added to them automatically.

FILES
  app.py                  the application and its window
  valuationpilot.ico      the application icon
  Start_ValuationPilot_Debug.bat   starts the app with an error window (for problems)
  Create_Desktop_Shortcut.bat      puts an icon on the Desktop
  valuation_engine.py     all calculations
  industries_data.py      built-in industry library (39 industries)
  report_text.py          standard wording for engagement, scope, sources, basis
  report_gen.py           Word report and Excel workbook builder
  templates\index.html    the screens
  industries.json         your saved industry figures (created on first run)
  cases\                  saved cases (one file per company)
  output\                 generated reports

WHAT THE REPORT CONTAINS
  Conclusion and football field; engagement, scope and sources (editable standard text);
  industry overview with basis for each figure; operating assumptions with basis;
  growth and margin for each year with the basis (formula for Auto years, your written
  reason for Manual years); WACC with basis; DCF with implied multiples; comparables and
  net assets; reconciliation and weights; sensitivity tables; best/base/worst scenarios;
  reasonableness checks; limitations; declarations; CA certificate and signature page.

BEFORE RELYING ON A REPORT
  - The built-in industry figures are INDICATIVE PLACEHOLDERS. Replace them with sourced
    data and fill the source and date fields on the Industry tab.
  - Words in [square brackets] in the report are for the CA to complete.
  - The standard wording (engagement, scope, sources, limitations, declarations and the
    certificate) is a template. Check it against the requirements for your purpose
    (law, regulator, engagement letter, ICAI standards) before signing.
  - Industries such as banks, NBFCs and holding companies need equity-based methods. The
    tool suggests weights for them, but add a book-value or sum-of-the-parts cross-check.
  - The tool prepares the valuation. The signing Chartered Accountant is responsible for
    every assumption and the conclusion.

MANUAL EDITS (for the CA)
  Open the Excel workbook. Yellow cells with blue text are inputs. Change any of them and
  everything recalculates. Write the reason for each change on the Basis sheet. To refresh
  the Word report, change the same figures in the app and generate again. Wording-only
  changes can be made directly in the Word file.

NOTE ON DISCOUNTING
  Cash flows use mid-year discounting. The Gordon growth terminal value is discounted at
  4.5 years and the exit-multiple terminal value at 5 years.
