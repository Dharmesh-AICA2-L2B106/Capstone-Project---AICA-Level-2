"""
ValuationPilot - report generator.
Builds (1) a print-ready Word valuation report with the basis for every assumption and a CA signing
page, and (2) an Excel workbook with LIVE formulas so the CA can edit any assumption.
"""
import os
import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
from valuation_engine import auto_growth, auto_margin

NAMES = {"dcf": "DCF (average of Gordon growth and exit multiple)", "ev_ebitda": "EV / EBITDA multiple",
         "ev_sales": "EV / Sales multiple", "pe": "P / E multiple", "nav": "Adjusted net asset value"}
BLUE = RGBColor(0x1F, 0x4E, 0x9C)


def inr(x):
    """Indian digit grouping, for example 12,34,567."""
    n = int(round(abs(x)))
    s = str(n)
    if len(s) > 3:
        head, tail = s[:-3], s[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:]); head = head[:-2]
        if head:
            parts.insert(0, head)
        s = ",".join(parts) + "," + tail
    return ("-" if x < 0 and n else "") + s


def pct(x, d=1): return f"{x * 100:.{d}f}%"
def pp(x): return f"{x * 100:+.1f} pp"


def shade(cell, hex_fill):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto"); shd.set(qn("w:fill"), hex_fill)
    tcPr.append(shd)


def set_widths(t, widths):
    """Word and LibreOffice both need the column grid and every cell set."""
    t.autofit = False
    for i, wd in enumerate(widths):
        t.columns[i].width = Cm(wd)
    for row in t.rows:
        for i, wd in enumerate(widths):
            row.cells[i].width = Cm(wd)


def add_table(doc, header, rows, widths=None, align=None, size=9, bold_last=False):
    """align: list of 'l' or 'r' for each column (default: first column left, others right)."""
    t = doc.add_table(rows=1, cols=len(header))
    t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER; t.autofit = False
    align = align or (["l"] + ["r"] * (len(header) - 1))
    for i, h in enumerate(header):
        c = t.rows[0].cells[i]; c.text = ""
        p = c.paragraphs[0]
        r = p.add_run(h); r.bold = True; r.font.size = Pt(size)
        if align[i] == "r":
            p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        shade(c, "D9E2F3")
    for ri, row in enumerate(rows):
        cells = t.add_row().cells
        last = bold_last and ri == len(rows) - 1
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]
            run = p.add_run(str(v)); run.font.size = Pt(size); run.bold = last
            if align[i] == "r":
                p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    if widths:
        set_widths(t, widths)
    for ri, row in enumerate(t.rows):
        trPr = row._tr.get_or_add_trPr()
        cs = OxmlElement("w:cantSplit"); trPr.append(cs)          # a row never breaks across pages
        if ri == 0 or len(t.rows) <= 14 and ri < len(t.rows) - 1:  # keep short tables together
            for cell in row.cells:
                for par in cell.paragraphs:
                    par.paragraph_format.keep_with_next = True
    doc.add_paragraph()
    return t


def render_block(doc, text):
    """Plain text with simple marks: '# Heading', '- bullet', everything else a paragraph."""
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("# "):
            doc.add_heading(line[2:].strip(), 2)
        elif line.startswith("- "):
            doc.add_paragraph(line[2:].strip(), style="List Bullet")
        else:
            doc.add_paragraph(line)


def note(doc, text, italic=True, size=9):
    p = doc.add_paragraph()
    r = p.add_run(text); r.italic = italic; r.font.size = Pt(size)
    return p


def add_field(par, instr, size=8):
    for tag, txt in (("begin", None), (None, instr), ("end", None)):
        run = par.add_run(); run.font.size = Pt(size)
        if tag:
            el = OxmlElement("w:fldChar"); el.set(qn("w:fldCharType"), tag); run._r.append(el)
        else:
            it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = txt; run._r.append(it)


def growth_basis_text(t, p, why, r, meta):
    ind, c = r["ind"], r["c"]
    manual = p.mode == "manual" and p.growth is not None
    if manual:
        return f"Manual: {pct(p.growth)}. Reason: {why or '[reason to be recorded]'}"
    s = (f"Auto: industry growth falls in a straight line from {pct(ind.current_growth)} (Year 1) to "
         f"{pct(ind.long_term_growth)} (Year 5). Year {t} = {pct(auto_growth(ind, t))}")
    if r["premium"]:
        s += f" {pp(r['premium'])} company adjustment = {pct(auto_growth(ind, t) + r['premium'])}."
    else:
        s += "."
    return s


def margin_basis_text(t, p, why, r, meta):
    ind, c = r["ind"], r["c"]
    if p.mode == "manual" and p.margin is not None:
        return f"Manual: {pct(p.margin)}. Reason: {why or '[reason to be recorded]'}"
    return (f"Auto: moves from the Company's base margin of {pct(c.base_ebitda_margin)} toward the industry target of "
            f"{pct(ind.target_margin)}, closing {pct(r['speed'], 0)} of the gap by Year 5. Year {t} = "
            f"{pct(auto_margin(c, ind, t, r['speed']))}.")


def build_word(path, r, meta):
    c, ind, plan, rows = r["c"], r["ind"], r["plan"], r["rows"]
    w, ke, kd, wi, vals, wts = r["w"], r["ke"], r["kd"], r["wi"], r["vals"], r["wts"]
    dres, comp, blended, unit = r["dres"], r["comp"], r["blended"], meta["unit"]
    B = meta["basis"]

    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21), Cm(29.7)
    sec.left_margin = sec.right_margin = Cm(2.0); sec.top_margin = Cm(2); sec.bottom_margin = Cm(2)
    st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(10.5)

    if meta.get("draft"):
        hp = sec.header.paragraphs[0]; hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        hr = hp.add_run("DRAFT - subject to review and signature by the Chartered Accountant")
        hr.font.size = Pt(8); hr.bold = True; hr.font.color.rgb = RGBColor(0xB4, 0x53, 0x09)
    fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    fr = fp.add_run(f"{meta['firm']} | Valuation of {c.name} | Page "); fr.font.size = Pt(8)
    add_field(fp, "PAGE")

    # ---- Cover
    for _ in range(5): doc.add_paragraph()
    h = doc.add_paragraph(); h.alignment = WD_ALIGN_PARAGRAPH.CENTER
    x = h.add_run("VALUATION REPORT"); x.bold = True; x.font.size = Pt(26)
    h = doc.add_paragraph(); h.alignment = WD_ALIGN_PARAGRAPH.CENTER
    x = h.add_run(c.name); x.bold = True; x.font.size = Pt(18)
    for line in (f"Industry: {ind.name}", f"Valuation date: {meta['val_date']}",
                 f"Purpose: {meta['purpose']}", f"Standard of value: {meta['standard']}",
                 f"Prepared for: {meta['client']}", f"Report date: {meta['report_date']}"):
        p = doc.add_paragraph(line); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for _ in range(4): doc.add_paragraph()
    p = doc.add_paragraph(meta["firm"]); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.runs[0].bold = True
    doc.add_page_break()

    # ---- 1 Conclusion
    doc.add_heading("1. Conclusion of value", 1)
    lo, hi = min(vals.values()), max(vals.values())
    doc.add_paragraph(
        f"Based on the analysis in this report, the equity value of {c.name} as at {meta['val_date']} is concluded "
        f"at INR {inr(blended)} {unit}, equivalent to INR {blended / c.shares:,.1f} per share. The individual methods "
        f"give a range of INR {inr(lo)} to INR {inr(hi)} {unit}.")
    add_table(doc, ["Method", f"Equity value (INR {unit})", "Weight"],
              [[NAMES.get(k, k), inr(v), pct(wts.get(k, 0))] for k, v in vals.items()] +
              [["Blended conclusion", inr(blended), "100.0%"]], widths=[9, 4.5, 3], bold_last=True)
    top = max(vals.values()) or 1
    bars = doc.add_table(rows=0, cols=3); bars.autofit = False
    for k, v in vals.items():
        cells = bars.add_row().cells
        cells[0].text = ""; cells[0].paragraphs[0].add_run(NAMES.get(k, k).split(" (")[0]).font.size = Pt(8.5)
        cells[1].text = ""
        br = cells[1].paragraphs[0].add_run("█" * max(1, round(max(v, 0) / top * 34)))
        br.font.size = Pt(8); br.font.color.rgb = BLUE
        cells[2].text = ""; cells[2].paragraphs[0].add_run(inr(v)).font.size = Pt(8.5)
        cells[2].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT
    set_widths(bars, (4.6, 9.4, 3.0))
    note(doc, "Bars compare the equity value from each method on the same scale.")

    # ---- 2 Engagement, scope, sources
    doc.add_heading("2. Engagement, scope and sources of information", 1)
    render_block(doc, meta["engagement"])
    render_block(doc, meta["scope"])
    render_block(doc, meta["sources"])

    # ---- 3 Industry
    doc.add_heading("3. Industry overview and assumptions", 1)
    if meta.get("ind_drivers"):
        p = doc.add_paragraph(); p.add_run("Demand drivers: ").bold = True; p.add_run(meta["ind_drivers"])
    if meta.get("ind_risks"):
        p = doc.add_paragraph(); p.add_run("Key risks: ").bold = True; p.add_run(meta["ind_risks"])
    if meta.get("ind_note"):
        p = doc.add_paragraph(); p.add_run("Method note: ").bold = True; p.add_run(meta["ind_note"])
    if meta.get("ind_basis_note"):
        doc.add_paragraph(meta["ind_basis_note"])
    src = ((ind.source or "[source]") + (f", {ind.as_of}" if ind.as_of else "")).strip()
    add_table(doc, ["Parameter", "Value", "Basis and source"], [
        ["Industry", ind.name, "Industry whose growth, margin and multiple data are used for the Company."],
        ["Current industry growth", pct(ind.current_growth),
         f"Industry growth per {src}. It is the starting growth rate (Year 1) for every year set to Auto."],
        ["Long-term industry growth", pct(ind.long_term_growth),
         f"Per {src}. Auto growth falls in a straight line from the current rate in Year 1 to this rate in Year 5. "
         "It is also the reference ceiling for the terminal growth rate."],
        ["Industry target EBITDA margin", pct(ind.target_margin),
         f"Per {src}. Auto margin moves from the Company's base margin toward this level, closing "
         f"{pct(r['speed'], 0)} of the gap by Year 5."],
        ["EV / EBITDA multiple", f"{ind.ev_ebitda:.1f}x",
         f"Peer multiple per {src}. Applied to the Company's base-year EBITDA after a {pct(r['disc'])} discount."],
        ["EV / Sales multiple", f"{ind.ev_sales:.1f}x",
         f"Peer multiple per {src}. Shown for reference and not weighted in the conclusion."],
        ["P / E multiple", f"{ind.pe:.1f}x",
         f"Peer multiple per {src}. Applied to the Company's base-year net profit after the same discount."],
    ], widths=[4.2, 2.6, 10.2], align=["l", "r", "l"], size=8.5)

    # ---- 4 Projection and basis
    doc.add_heading("4. Five-year projection and basis", 1)
    doc.add_heading("Operating assumptions", 2)
    prem_basis = ("No company-specific adjustment is applied to the industry growth rate." if not r["premium"] else
                  f"Adjustment of {pp(r['premium'])} added to the industry growth rate for Auto years. [Explain the reason.]")
    add_table(doc, ["Assumption", "Value", "Basis"], [
        ["Base-year revenue", f"{inr(c.base_revenue)}", "As per the base-year financial statements. [Add year.]"],
        ["Base-year EBITDA margin", pct(c.base_ebitda_margin), B["base_margin"]],
        ["Tax rate", pct(c.tax_rate), B["tax"]],
        ["Depreciation % of sales", pct(c.dep_pct_sales), B["dep"]],
        ["Capex % of sales", pct(c.capex_pct_sales), B["capex"]],
        ["Net working capital % of sales", pct(c.nwc_pct_sales), B["nwc"]],
        ["Company growth adjustment", pp(r["premium"]), prem_basis],
    ], widths=[4.6, 2.4, 10.0], align=["l", "r", "l"], size=8.5)

    doc.add_heading("Growth and margin by year", 2)
    yrs = []
    for i, (p, why) in enumerate(zip(plan, r["plan_basis"]), 1):
        yrs.append([f"Year {i}", pct(rows[i - 1]["growth"]), growth_basis_text(i, p, why, r, meta),
                    pct(rows[i - 1]["margin"]), margin_basis_text(i, p, why, r, meta)])
    add_table(doc, ["Year", "Growth", "Basis of growth", "EBITDA margin", "Basis of margin"], yrs,
              widths=[1.4, 1.6, 6.2, 1.8, 6.0], align=["l", "r", "l", "r", "l"], size=8)

    doc.add_heading("Projection", 2)
    hdr = [f"INR {unit}", "Base"] + [f"Y{x['year']}" for x in rows]

    def line(label, base, key, f=inr):
        return [label, base] + [f(x[key]) for x in rows]
    add_table(doc, hdr, [
        line("Revenue", inr(c.base_revenue), "revenue"),
        line("EBITDA margin", pct(c.base_ebitda_margin), "margin", pct),
        line("EBITDA", inr(c.base_revenue * c.base_ebitda_margin), "ebitda"),
        line("Depreciation", "", "dep"), line("EBIT", "", "ebit"), line("Tax", "", "tax"),
        line("Capex", "", "capex"), line("Increase in working capital", "", "d_nwc"),
        line("Free cash flow to firm", "", "fcff")], widths=[4.6, 2.0, 2.0, 2.0, 2.0, 2.0, 2.0], bold_last=True)

    # ---- 5 WACC
    doc.add_heading("5. Discount rate (WACC)", 1)
    add_table(doc, ["Component", "Value", "Basis"], [
        ["Risk-free rate", pct(wi["rf"], 2), B["rf"]],
        ["Equity risk premium", pct(wi["erp"], 2), B["erp"]],
        ["Beta", f"{wi['beta']:.2f}", B["beta"]],
        ["Size premium", pct(wi["size"], 2), B["size"]],
        ["Company-specific premium", pct(wi["spec"], 2), B["spec"]],
        ["Cost of equity", pct(ke, 2), "Risk-free rate + beta x equity risk premium + size premium + company-specific premium."],
        ["Pre-tax cost of debt", pct(wi["kd_pre"], 2), B["kd"]],
        ["After-tax cost of debt", pct(kd, 2), f"Pre-tax cost of debt x (1 - tax rate of {pct(c.tax_rate)})."],
        ["Debt weight", pct(wi["dw"], 1), B["dw"]],
        ["WACC", pct(w, 2), "Cost of equity x equity weight + after-tax cost of debt x debt weight."],
    ], widths=[4.2, 2.2, 10.6], align=["l", "r", "l"], size=8.5, bold_last=True)

    # ---- 6 DCF
    doc.add_heading("6. Discounted cash flow", 1)
    add_table(doc, ["", "Gordon growth", "Exit multiple"], [
        ["Terminal assumption", f"g = {pct(meta['g'])}", f"{meta['exit_mult']:.1f}x EBITDA"],
        ["Terminal value", inr(dres["gordon"]["tv"]), inr(dres["exit_multiple"]["tv"])],
        ["Enterprise value", inr(dres["gordon"]["ev"]), inr(dres["exit_multiple"]["ev"])],
        ["Add cash, less debt", inr(c.cash - c.debt), inr(c.cash - c.debt)],
        ["Equity value", inr(dres["gordon"]["equity"]), inr(dres["exit_multiple"]["equity"])],
        ["Share of enterprise value from terminal value", pct(r["implied"]["tv_share_gordon"] or 0, 0),
         pct(r["implied"]["tv_share_exit"] or 0, 0)],
        ["Implied EV / base-year EBITDA", f"{(r['implied']['ev_ebitda_gordon'] or 0):.1f}x",
         f"{(r['implied']['ev_ebitda_exit'] or 0):.1f}x"],
    ], widths=[7.4, 4.8, 4.8])
    p = doc.add_paragraph(); p.add_run("Basis of terminal growth: ").bold = True; p.add_run(B["term_g"])
    p = doc.add_paragraph(); p.add_run("Basis of exit multiple: ").bold = True; p.add_run(B["exit_mult"])
    note(doc, "Cash flows are discounted at mid-year. The Gordon growth terminal value is discounted at 4.5 years and "
              "the exit-multiple terminal value at 5 years.")
    if meta.get("dlom", 0) > 0:
        p = doc.add_paragraph(); p.add_run(f"Discount for lack of marketability ({pct(meta['dlom'])}): ").bold = True
        p.add_run(B["dlom"])

    # ---- 7 Comparables and NAV
    doc.add_heading("7. Relative valuation and net asset value", 1)
    base_ebitda = c.base_revenue * c.base_ebitda_margin
    rel = [["EV / EBITDA", f"{ind.ev_ebitda:.1f}x", f"Base-year EBITDA of {inr(base_ebitda)}", inr(comp["ev_ebitda"])],
           ["EV / Sales", f"{ind.ev_sales:.1f}x", f"Base-year revenue of {inr(c.base_revenue)}", inr(comp["ev_sales"])]]
    if "pe" in comp:
        rel.append(["P / E", f"{ind.pe:.1f}x", f"Base-year net profit of {inr(c.base_net_profit)}", inr(comp["pe"])])
    rel.append(["Adjusted net asset value", "-", "Fair value of assets less liabilities", inr(c.adjusted_net_assets)])
    add_table(doc, ["Method", "Multiple", "Applied to", f"Equity value (INR {unit})"], rel,
              widths=[4.2, 2.2, 7.0, 3.6], align=["l", "r", "l", "r"])
    p = doc.add_paragraph(); p.add_run("Basis of discount on multiples: ").bold = True
    p.add_run(f"{pct(r['disc'])}. " + B["comp_discount"])
    p = doc.add_paragraph(); p.add_run("Basis of adjusted net assets: ").bold = True; p.add_run(B["nav"])
    note(doc, "For EV-based methods, equity value = enterprise value - debt + cash, then reduced by the discount. "
              "EV / Sales is shown for reference and is not weighted in the conclusion.")

    # ---- 8 Reconciliation
    doc.add_heading("8. Reconciliation of methods and weights", 1)
    add_table(doc, ["Method", f"Equity value (INR {unit})", "Weight", f"Contribution (INR {unit})"],
              [[NAMES.get(k, k), inr(v), pct(wts.get(k, 0)), inr(v * wts.get(k, 0))] for k, v in vals.items()] +
              [["Blended conclusion", inr(blended), "100.0%", inr(blended)]],
              widths=[7.6, 3.4, 2.2, 3.8], bold_last=True)
    p = doc.add_paragraph(); p.add_run("Basis of weights: ").bold = True; p.add_run(B["weights"])

    # ---- 9 Sensitivity
    doc.add_heading("9. Sensitivity", 1)
    doc.add_paragraph("DCF equity value (Gordon growth) by WACC and terminal growth rate:")
    ws = sorted({k[0] for k in r["grid"]}); gs = sorted({k[1] for k in r["grid"]})
    add_table(doc, ["WACC \\ terminal growth"] + [pct(g) for g in gs],
              [[pct(x, 2)] + [inr(r["grid"][(x, g)]) for g in gs] for x in ws])
    doc.add_paragraph("DCF equity value (exit multiple) by WACC and exit multiple:")
    ms = sorted({k[1] for k in r["grid_exit"]})
    add_table(doc, ["WACC \\ exit multiple"] + [f"{m:.1f}x" for m in ms],
              [[pct(x, 2)] + [inr(r["grid_exit"][(x, m)]) for m in ms] for x in ws])

    # ---- 10 Scenarios
    doc.add_heading("10. Scenario analysis", 1)
    srows = []
    for s in r["scenarios"]:
        if s.get("skipped"):
            srows.append([s["label"], pp(s["growth_adj"]), pp(s["margin_adj"]), "-", "-", "-", "Not computed: WACC too close to terminal growth"])
        else:
            srows.append([s["label"], pp(s["growth_adj"]), pp(s["margin_adj"]), pct(s["wacc"], 2),
                          inr(s["revenue5"]), inr(s["dcf"]), inr(s["blended"])])
    add_table(doc, ["Scenario", "Growth change", "Margin change", "WACC", "Year 5 revenue", "DCF equity", "Blended equity"],
              srows, widths=[2.4, 2.2, 2.2, 1.9, 2.6, 2.6, 3.1], size=8.5)
    note(doc, "Scenarios change the DCF inputs (growth in every year, EBITDA margin in every year, and WACC). The market "
              "and asset methods are not changed, so the blended value moves by less than the DCF value.")

    # ---- 11 Checks
    doc.add_heading("11. Reasonableness checks", 1)
    if r["checks"]:
        for ck in r["checks"]:
            p = doc.add_paragraph(style="List Bullet")
            lab = p.add_run("Attention: " if ck["level"] == "warn" else "Note: "); lab.bold = True
            p.add_run(ck["text"])
    else:
        doc.add_paragraph("The automatic checks found nothing to report.")

    # ---- 12 Limitations, 13 Declarations
    doc.add_heading("12. Key assumptions, limitations and reliance", 1)
    for t in meta["limitations"]:
        doc.add_paragraph(t, style="List Bullet")
    doc.add_heading("13. Declarations", 1)
    for t in meta["declarations"]:
        doc.add_paragraph(t, style="List Bullet")

    # ---- 14 Certificate
    doc.add_page_break()
    doc.add_heading("14. Certificate and signature of Chartered Accountant", 1)
    doc.add_paragraph(meta["certificate_text"])
    doc.add_paragraph()
    sig = doc.add_table(rows=6, cols=2); sig.style = "Table Grid"
    items = [("Name of Chartered Accountant", meta["ca_name"]), ("Membership No.", meta["membership_no"]),
             ("Firm name and Registration No.", meta["firm_reg"]),
             ("Registered Valuer Registration No. (if applicable)", meta["rv_no"]),
             ("UDIN", meta["udin"]), ("Place and date", meta["place_date"])]
    for i, (a, b) in enumerate(items):
        sig.rows[i].cells[0].text = a; sig.rows[i].cells[1].text = b
        sig.rows[i].cells[0].paragraphs[0].runs[0].bold = True
    set_widths(sig, (7.0, 9.5))
    for _ in range(3): doc.add_paragraph()
    doc.add_paragraph("Signature: ______________________________          Seal of the firm")
    p = doc.add_paragraph("\nCalculations generated by ValuationPilot. Every figure and every statement of basis is to be "
                          "reviewed by the signing Chartered Accountant before signature.")
    p.runs[0].font.size = Pt(8); p.runs[0].italic = True
    doc.save(path)


def build_excel(path, c, ind, plan, wacc_inputs, meta):
    """Workbook with live formulas. The CA edits the yellow cells with blue text and every other
    cell recalculates. It reproduces the base case; scenarios and text are in the Word report."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    wb = Workbook()
    blue = Font(color="0000FF", bold=True)
    fill = PatternFill("solid", fgColor="FFF2CC")
    bold = Font(bold=True)
    wts = meta.get("weights") or {"dcf": 0.5, "ev_ebitda": 0.2, "pe": 0.1, "nav": 0.2}
    has_pe = c.base_net_profit is not None

    a = wb.active; a.title = "Inputs"
    inputs = [("Company", c.name), ("Base revenue", c.base_revenue), ("Base EBITDA margin", c.base_ebitda_margin),
              ("Tax rate", c.tax_rate), ("Depreciation % sales", c.dep_pct_sales), ("Capex % sales", c.capex_pct_sales),
              ("NWC % sales", c.nwc_pct_sales), ("Debt", c.debt), ("Cash", c.cash), ("Shares", c.shares),
              ("Base net profit", c.base_net_profit or 0), ("Adjusted net assets", c.adjusted_net_assets),
              ("Industry current growth", ind.current_growth), ("Industry long-term growth", ind.long_term_growth),
              ("Industry target margin", ind.target_margin),
              ("Company growth premium", meta.get("premium", 0.0)), ("Margin speed", meta.get("margin_speed", 0.5)),
              ("EV/EBITDA", ind.ev_ebitda), ("EV/Sales", ind.ev_sales), ("P/E", ind.pe),
              ("Risk-free", wacc_inputs["rf"]), ("ERP", wacc_inputs["erp"]), ("Beta", wacc_inputs["beta"]),
              ("Size premium", wacc_inputs["size"]), ("Specific premium", wacc_inputs["spec"]),
              ("Pre-tax cost of debt", wacc_inputs["kd_pre"]), ("Debt weight", wacc_inputs["dw"]),
              ("Terminal growth", meta["g"]), ("Exit multiple", meta["exit_mult"]),
              ("Comparable discount", meta["comp_discount"]), ("DLOM", meta.get("dlom", 0.0))]
    a["A1"], a["B1"] = "Input", "Value (edit yellow cells)"
    a["A1"].font = a["B1"].font = bold
    ref = {}
    for i, (k, v) in enumerate(inputs, start=2):
        a.cell(i, 1, k); cell = a.cell(i, 2, v); cell.font = blue; cell.fill = fill
        ref[k] = f"Inputs!$B${i}"
        if isinstance(v, float) and abs(v) < 1 and k not in ("Beta", "Margin speed"):
            cell.number_format = "0.0%"
    a.column_dimensions["A"].width = 30; a.column_dimensions["B"].width = 26

    p = wb.create_sheet("Plan")
    for j, h in enumerate(["Item", "Base", "Y1", "Y2", "Y3", "Y4", "Y5"], 1):
        p.cell(1, j, h).font = bold
    labels = ["Mode (auto / manual)", "Manual growth", "Manual margin (blank = auto)", "Growth used",
              "Margin used", "Revenue", "EBITDA", "Depreciation", "EBIT", "Tax", "Capex", "NWC",
              "Change in NWC", "FCFF"]
    for i, l in enumerate(labels, 2):
        p.cell(i, 1, l)
    p.cell(7, 2, f"={ref['Base revenue']}")
    p.cell(13, 2, f"={ref['Base revenue']}*{ref['NWC % sales']}")
    for t in range(1, 6):
        col = 2 + t
        L = p.cell(1, col).column_letter; P = p.cell(1, col - 1).column_letter
        pl = plan[t - 1]
        for rr, v in ((2, pl.mode), (3, pl.growth), (4, pl.margin)):
            cc = p.cell(rr, col, v); cc.font = blue; cc.fill = fill
        p.cell(5, col, f'=IF(AND({L}2="manual",{L}3<>""),{L}3,{ref["Industry current growth"]}+'
                       f'({ref["Industry long-term growth"]}-{ref["Industry current growth"]})*({t}-1)/4+{ref["Company growth premium"]})')
        p.cell(6, col, f'=IF(AND({L}2="manual",{L}4<>""),{L}4,{ref["Base EBITDA margin"]}+({ref["Industry target margin"]}-{ref["Base EBITDA margin"]})*{ref["Margin speed"]}*{t}/5)')
        p.cell(7, col, f"={P}7*(1+{L}5)")
        p.cell(8, col, f"={L}7*{L}6")
        p.cell(9, col, f"={L}7*{ref['Depreciation % sales']}")
        p.cell(10, col, f"={L}8-{L}9")
        p.cell(11, col, f"=MAX({L}10,0)*{ref['Tax rate']}")
        p.cell(12, col, f"={L}7*{ref['Capex % sales']}")
        p.cell(13, col, f"={L}7*{ref['NWC % sales']}")
        p.cell(14, col, f"={L}13-{P}13")
        p.cell(15, col, f"={L}10-{L}11+{L}9-{L}12-{L}14")
    p.column_dimensions["A"].width = 32

    v = wb.create_sheet("Valuation")
    rows_v = [
        ("Cost of equity", f"={ref['Risk-free']}+{ref['Beta']}*{ref['ERP']}+{ref['Size premium']}+{ref['Specific premium']}"),
        ("After-tax cost of debt", f"={ref['Pre-tax cost of debt']}*(1-{ref['Tax rate']})"),
        ("WACC", f"=(1-{ref['Debt weight']})*B2+{ref['Debt weight']}*B3"),
        ("PV of FCFF (mid-year)", "=" + "+".join(f"Plan!{chr(67 + i)}15/(1+B4)^({i + 1}-0.5)" for i in range(5))),
        ("Terminal value Gordon", f"=Plan!G15*(1+{ref['Terminal growth']})/(B4-{ref['Terminal growth']})"),
        ("Terminal value Exit", f"=Plan!G8*{ref['Exit multiple']}"),
        ("EV Gordon", "=B5+B6/(1+B4)^4.5"),
        ("EV Exit", "=B5+B7/(1+B4)^5"),
        ("DCF equity Gordon", f"=(B8-{ref['Debt']}+{ref['Cash']})*(1-{ref['DLOM']})"),
        ("DCF equity Exit", f"=(B9-{ref['Debt']}+{ref['Cash']})*(1-{ref['DLOM']})"),
        ("DCF equity average", "=AVERAGE(B10,B11)"),
        ("EV/EBITDA equity", f"=({ref['Base revenue']}*{ref['Base EBITDA margin']}*{ref['EV/EBITDA']}-{ref['Debt']}+{ref['Cash']})*(1-{ref['Comparable discount']})"),
        ("P/E equity", f"={ref['Base net profit']}*{ref['P/E']}*(1-{ref['Comparable discount']})"),
        ("NAV", f"={ref['Adjusted net assets']}"),
    ]
    v["A1"], v["B1"] = "Item", "Value"; v["A1"].font = v["B1"].font = bold
    for i, (k, f) in enumerate(rows_v, 2):
        v.cell(i, 1, k); v.cell(i, 2, f)
    v.cell(17, 1, "Method weights (edit)").font = bold
    wlist = (("DCF", wts.get("dcf", 0), "B12"), ("EV/EBITDA", wts.get("ev_ebitda", 0), "B13"),
             ("P/E", wts.get("pe", 0) if has_pe else 0, "B14"), ("NAV", wts.get("nav", 0), "B15"))
    for i, (k, wv, src) in enumerate(wlist, 18):
        v.cell(i, 1, k); cc = v.cell(i, 2, wv); cc.font = blue; cc.fill = fill; v.cell(i, 3, f"={src}")
    v.cell(23, 1, "BLENDED EQUITY VALUE").font = bold
    v.cell(23, 2, "=SUMPRODUCT(B18:B21,C18:C21)/SUM(B18:B21)").font = bold
    v.cell(24, 1, "Per share"); v.cell(24, 2, f"=B23/{ref['Shares']}")
    v.column_dimensions["A"].width = 30; v.column_dimensions["B"].width = 18

    # Basis sheet: the written basis for each assumption, next to its value
    B = meta.get("basis", {})
    bs = wb.create_sheet("Basis")
    bs["A1"], bs["B1"], bs["C1"] = "Assumption", "Value", "Basis"
    for cell in (bs["A1"], bs["B1"], bs["C1"]):
        cell.font = bold
    brows = [("Base EBITDA margin", c.base_ebitda_margin, B.get("base_margin", "")),
             ("Tax rate", c.tax_rate, B.get("tax", "")), ("Depreciation % sales", c.dep_pct_sales, B.get("dep", "")),
             ("Capex % sales", c.capex_pct_sales, B.get("capex", "")), ("NWC % sales", c.nwc_pct_sales, B.get("nwc", "")),
             ("Risk-free rate", wacc_inputs["rf"], B.get("rf", "")), ("Equity risk premium", wacc_inputs["erp"], B.get("erp", "")),
             ("Beta", wacc_inputs["beta"], B.get("beta", "")), ("Size premium", wacc_inputs["size"], B.get("size", "")),
             ("Company-specific premium", wacc_inputs["spec"], B.get("spec", "")),
             ("Pre-tax cost of debt", wacc_inputs["kd_pre"], B.get("kd", "")), ("Debt weight", wacc_inputs["dw"], B.get("dw", "")),
             ("Terminal growth", meta["g"], B.get("term_g", "")), ("Exit multiple", meta["exit_mult"], B.get("exit_mult", "")),
             ("Discount on comparables", meta["comp_discount"], B.get("comp_discount", "")),
             ("Discount for lack of marketability", meta.get("dlom", 0), B.get("dlom", "")),
             ("Method weights", "see Valuation sheet", B.get("weights", "")), ("Adjusted net assets", c.adjusted_net_assets, B.get("nav", ""))]
    for i, (k, val, why) in enumerate(brows, 2):
        bs.cell(i, 1, k); bs.cell(i, 2, val); cc = bs.cell(i, 3, why)
        cc.alignment = Alignment(wrap_text=True, vertical="top")
    bs.column_dimensions["A"].width = 34; bs.column_dimensions["B"].width = 20; bs.column_dimensions["C"].width = 110

    # How to edit
    h = wb.create_sheet("How to edit")
    guide = ["HOW THE CA CAN EDIT THIS VALUATION",
             "",
             "1. Inputs sheet: change any yellow cell with blue text (financials, industry rates, WACC parts, terminal growth, exit multiple, discounts).",
             "2. Plan sheet: for each year type auto or manual in row 2. For manual, type the growth in row 3 and, if needed, the margin in row 4.",
             "   Leave a manual margin blank to keep the industry-linked margin for that year.",
             "3. Valuation sheet: change the method weights (blue cells) and read the blended equity value and the per-share value.",
             "4. Record the reason for every change in the Basis sheet, so the file shows why the figure was changed.",
             "5. This workbook reproduces the base case. Scenarios, reasonableness checks and the written report are in the Word file.",
             "6. To refresh the Word report with changed figures, enter the same figures in ValuationPilot and generate again.",
             "   For wording-only changes, edit the Word file directly.",
             "",
             "Values in this workbook are formulas. Do not overwrite a white cell unless you mean to replace its formula."]
    for i, t in enumerate(guide, 1):
        h.cell(i, 1, t)
    h["A1"].font = Font(bold=True, size=12)
    h.column_dimensions["A"].width = 140
    wb.save(path)
