"""
ValuationPilot - calculation engine.
Python does all arithmetic. Amounts are in whatever unit you choose (default INR lakh).
"""
from dataclasses import dataclass
from typing import List, Dict, Optional


@dataclass
class Company:
    name: str
    base_revenue: float
    base_ebitda_margin: float          # e.g. 0.16
    tax_rate: float = 0.25
    dep_pct_sales: float = 0.03
    capex_pct_sales: float = 0.05
    nwc_pct_sales: float = 0.15
    debt: float = 0.0
    cash: float = 0.0
    shares: float = 1.0
    base_net_profit: Optional[float] = None
    adjusted_net_assets: float = 0.0


@dataclass
class Industry:
    name: str
    current_growth: float
    long_term_growth: float
    target_margin: float
    ev_ebitda: float
    ev_sales: float
    pe: float
    source: str = "user entered"
    as_of: str = ""


@dataclass
class YearPlan:
    mode: str = "auto"                 # "auto" or "manual"
    growth: Optional[float] = None
    margin: Optional[float] = None


def auto_growth(ind: Industry, t: int) -> float:
    """Industry growth for year t (1 to 5) before any company premium: fades in a straight line
    from the industry's current growth in Year 1 to its long-term growth in Year 5."""
    return ind.current_growth + (ind.long_term_growth - ind.current_growth) * (t - 1) / 4


def auto_margin(c: Company, ind: Industry, t: int, margin_speed: float = 0.5) -> float:
    """EBITDA margin for year t: moves from the company's base margin toward the industry target."""
    return c.base_ebitda_margin + (ind.target_margin - c.base_ebitda_margin) * margin_speed * t / 5


def build_projection(c: Company, ind: Industry, plan: List[YearPlan],
                     company_premium: float = 0.0, margin_speed: float = 0.5,
                     growth_adj: float = 0.0, margin_adj: float = 0.0):
    """Auto growth fades linearly from industry current growth to long-term growth by
    year 5, plus an optional company premium. Auto margin moves from the company's
    margin toward the industry target margin. Manual years use the figure typed in."""
    rows, prev_rev, prev_nwc = [], c.base_revenue, c.base_revenue * c.nwc_pct_sales
    for t in range(1, 6):
        p = plan[t - 1]
        if p.mode == "manual" and p.growth is not None:
            g = p.growth
        else:
            g = auto_growth(ind, t) + company_premium
        if p.mode == "manual" and p.margin is not None:
            m = p.margin
        else:
            m = auto_margin(c, ind, t, margin_speed)
        g += growth_adj          # scenario adjustments (zero in the base case)
        m += margin_adj
        rev = prev_rev * (1 + g)
        ebitda = rev * m
        dep = rev * c.dep_pct_sales
        ebit = ebitda - dep
        tax = max(ebit, 0) * c.tax_rate
        capex = rev * c.capex_pct_sales
        nwc = rev * c.nwc_pct_sales
        d_nwc = nwc - prev_nwc
        fcff = ebit - tax + dep - capex - d_nwc
        rows.append(dict(year=t, growth=g, revenue=rev, margin=m, ebitda=ebitda,
                         dep=dep, ebit=ebit, tax=tax, capex=capex, d_nwc=d_nwc, fcff=fcff))
        prev_rev, prev_nwc = rev, nwc
    return rows


def wacc(rf, erp, beta, size_prem, specific_prem, kd_pre, tax, debt_weight):
    ke = rf + beta * erp + size_prem + specific_prem
    kd = kd_pre * (1 - tax)
    return (1 - debt_weight) * ke + debt_weight * kd, ke, kd


def dcf(rows, w, g_terminal, exit_multiple, c: Company, mid_year=True, dlom=0.0):
    """Mid-year convention: cash flows discounted at t-0.5. The Gordon terminal value
    is discounted at N-0.5 (it is built from mid-year flows); the exit-multiple terminal
    value is a year-end sale value, so it is discounted at N."""
    pv = 0.0
    for r in rows:
        t = r["year"] - (0.5 if mid_year else 0)
        pv += r["fcff"] / (1 + w) ** t
    last = rows[-1]
    tv_gordon = last["fcff"] * (1 + g_terminal) / (w - g_terminal)
    tv_exit = last["ebitda"] * exit_multiple
    n_gordon = 5 - (0.5 if mid_year else 0)
    out = {}
    for label, tv, n in (("gordon", tv_gordon, n_gordon), ("exit_multiple", tv_exit, 5)):
        ev = pv + tv / (1 + w) ** n
        eq = (ev - c.debt + c.cash) * (1 - dlom)
        out[label] = dict(tv=tv, ev=ev, equity=eq)
    return out


def comparables(c: Company, ind: Industry, discount=0.0):
    ev1 = c.base_revenue * c.base_ebitda_margin * ind.ev_ebitda
    ev2 = c.base_revenue * ind.ev_sales
    out = {"ev_ebitda": (ev1 - c.debt + c.cash) * (1 - discount),
           "ev_sales": (ev2 - c.debt + c.cash) * (1 - discount)}
    if c.base_net_profit is not None:
        out["pe"] = c.base_net_profit * ind.pe * (1 - discount)
    return out


def blend(values: Dict[str, float], weights: Dict[str, float]):
    tw = sum(weights.get(k, 0) for k in values)
    return sum(values[k] * weights.get(k, 0) for k in values) / tw


def sensitivity(rows, c, wacc_list, g_list, exit_multiple, dlom=0.0):
    return {(round(w, 4), round(g, 4)): dcf(rows, w, g, exit_multiple, c, dlom=dlom)["gordon"]["equity"]
            for w in wacc_list for g in g_list}


def sensitivity_exit(rows, c, wacc_list, mult_list, g_terminal, dlom=0.0):
    """DCF equity value by exit multiple for a range of WACC values."""
    return {(round(w, 4), round(m, 2)): dcf(rows, w, g_terminal, m, c, dlom=dlom)["exit_multiple"]["equity"]
            for w in wacc_list for m in mult_list}


if __name__ == "__main__":
    c = Company("Demo Industries", 5000, 0.16, debt=600, cash=150, shares=10,
                base_net_profit=420, adjusted_net_assets=2100)
    ind = Industry("Specialty chemicals", 0.13, 0.07, 0.19, 11.0, 1.8, 20.0)
    rows = build_projection(c, ind, [YearPlan() for _ in range(5)])
    w, ke, kd = wacc(0.07, 0.065, 1.1, 0.02, 0.01, 0.10, c.tax_rate, 0.20)
    print("WACC", round(w, 4), "DCF", {k: round(v["equity"]) for k, v in dcf(rows, w, 0.05, 10, c).items()})
