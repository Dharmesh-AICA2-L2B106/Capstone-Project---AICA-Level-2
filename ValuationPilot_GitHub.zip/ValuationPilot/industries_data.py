"""
ValuationPilot - built-in industry library.

IMPORTANT: every number below is an INDICATIVE PLACEHOLDER to get you started, not sourced
market data. Replace growth, margin and multiple figures with current, sourced data
(industry reports, listed-peer data, rating-agency or brokerage research) and record the
source and date in the Industry tab before relying on any report.

The qualitative notes (drivers, risks, method notes) are general descriptions to be edited
by the valuer.
"""

PLACEHOLDER = "INDICATIVE PLACEHOLDER - replace with sourced data"

# name: (current growth, long-term growth, target EBITDA margin, EV/EBITDA, EV/Sales, P/E, beta,
#        drivers, risks)
_ROWS = [
    ("Specialty chemicals", .13, .07, .19, 11.0, 1.8, 20, 1.10,
     "Import substitution, China+1 sourcing shift, demand from agrochemical, pharma and consumer end-markets.",
     "Raw material price swings, environmental compliance, customer concentration, pricing pressure from imports."),
    ("Commodity chemicals", .08, .05, .15, 7.0, 1.0, 14, 1.15,
     "Domestic demand growth, capacity additions, downstream industrial consumption.",
     "Cyclical spreads, feedstock and energy costs, global oversupply, regulatory and environmental costs."),
    ("Pharmaceuticals (formulations)", .10, .06, .22, 14.0, 3.0, 26, 0.85,
     "Domestic chronic-therapy demand, export generics, complex generics and CDMO opportunities.",
     "Price controls, regulatory inspections, US generic price erosion, R&D failure risk."),
    ("Healthcare services / hospitals", .12, .07, .21, 16.0, 3.2, 30, 0.85,
     "Rising insurance coverage, medical tourism, capacity additions in tier-2 cities, higher-value procedures.",
     "Regulated tariffs, doctor availability, long gestation of new hospitals, payer concentration."),
    ("Diagnostics", .13, .08, .25, 18.0, 4.0, 35, 0.80,
     "Preventive health awareness, higher test volumes per capita, formalisation from unorganised labs.",
     "Pricing competition, collection network costs, regulatory changes, technology disruption."),
    ("IT services", .10, .06, .22, 14.0, 3.0, 24, 0.95,
     "Digital transformation spends, cloud migration, global delivery model, deal pipeline in BFSI and healthcare.",
     "Client concentration, visa and wage inflation, currency movement, AI-led pricing pressure."),
    ("Software / SaaS", .16, .09, .25, 18.0, 5.0, 32, 1.05,
     "Recurring subscription revenue, global enterprise adoption, low incremental cost of delivery.",
     "Customer churn, competition from large platforms, long sales cycles, dependence on a few products."),
    ("BPO / KPO", .09, .06, .18, 10.0, 1.8, 20, 0.95,
     "Offshoring of back-office and analytics work, cost arbitrage, automation-led services.",
     "Wage inflation, automation reducing headcount-based revenue, client concentration, data-security obligations."),
    ("FMCG", .09, .06, .18, 20.0, 3.5, 35, 0.75,
     "Rural and urban consumption growth, premiumisation, distribution reach, brand strength.",
     "Input cost inflation, competition from local and D2C brands, trade-channel shifts."),
    ("Food processing", .10, .06, .12, 12.0, 1.3, 24, 0.85,
     "Packaged food adoption, processed exports, organised retail and quick-commerce channels.",
     "Commodity price volatility, working capital intensity, food-safety compliance, brand-building cost."),
    ("Beverages and dairy", .09, .06, .14, 13.0, 1.6, 25, 0.80,
     "Rising per-capita consumption, value-added dairy products, cold-chain expansion.",
     "Milk procurement cost, regulatory pricing or taxation, weather and seasonality."),
    ("Retail (general)", .11, .06, .08, 12.0, 0.9, 28, 1.00,
     "Organised retail penetration, rising discretionary income, omnichannel formats.",
     "Thin margins, high rentals, inventory risk, competition from e-commerce."),
    ("E-commerce / internet platforms", .20, .09, .08, 15.0, 2.5, 40, 1.20,
     "Internet penetration, digital payments, logistics improvement, rising online share of retail.",
     "Cash burn and funding risk, customer acquisition cost, regulatory scrutiny, intense competition."),
    ("Textiles and apparel", .08, .05, .13, 8.0, 1.0, 16, 1.00,
     "Export orders, PLI and textile-park support, domestic branded apparel growth.",
     "Cotton and yarn price swings, export demand cycles, labour availability, compliance costs."),
    ("Auto components", .10, .06, .13, 11.0, 1.5, 22, 1.05,
     "Vehicle production growth, premiumisation, EV content, export and aftermarket demand.",
     "OEM concentration, EV transition risk to ICE components, commodity costs, OEM price negotiations."),
    ("Automobiles", .07, .05, .11, 10.0, 1.1, 20, 1.05,
     "Replacement demand, new launches, financing availability, EV adoption.",
     "Cyclical demand, input and fuel costs, regulatory changes, technology transition."),
    ("Engineering and capital goods", .11, .06, .13, 15.0, 2.0, 30, 1.10,
     "Capex cycle in power, rail, defence and manufacturing; order-book visibility.",
     "Order delays, execution and working capital risk, raw material pass-through, government spending cycles."),
    ("Manufacturing (general)", .10, .06, .14, 9.0, 1.2, 18, 1.05,
     "Domestic demand growth, formalisation, capacity utilisation, export opportunities.",
     "Raw material costs, working capital intensity, technology obsolescence, customer concentration."),
    ("Steel and metals", .06, .04, .16, 6.0, 1.0, 11, 1.25,
     "Infrastructure and construction demand, capacity expansion, domestic consumption growth.",
     "Highly cyclical prices, import pressure, coking coal and ore costs, high capital intensity."),
    ("Cement", .07, .05, .20, 11.0, 2.0, 24, 0.95,
     "Housing and infrastructure demand, capacity additions, operating leverage.",
     "Regional oversupply, fuel and freight costs, cyclical demand, environmental norms."),
    ("Building materials and ceramics", .09, .06, .15, 12.0, 1.7, 26, 1.00,
     "Housing and real-estate activity, premium product mix, retail and dealer network expansion.",
     "Gas and input costs, real-estate cycle, competition from unorganised players."),
    ("Construction and EPC", .10, .06, .11, 8.0, 0.8, 15, 1.20,
     "Government infrastructure spending, urbanisation, order inflow in roads, water and rail.",
     "Delayed payments, working capital and debt levels, execution risk, fixed-price contract risk."),
    ("Real estate (developers)", .08, .05, .25, 13.0, 2.5, 22, 1.20,
     "Housing demand, rising incomes, RERA-driven consolidation toward organised developers.",
     "Interest-rate sensitivity, approvals and land cost, cash-flow lumpiness, project delays."),
    ("Power and renewables", .09, .05, .40, 9.0, 3.6, 16, 0.95,
     "Rising electricity demand, renewable capacity targets, long-term power purchase agreements.",
     "Counterparty payment delays, regulatory tariff changes, high leverage, project execution risk."),
    ("Oil, gas and energy services", .06, .04, .15, 7.0, 1.0, 12, 1.10,
     "Domestic energy demand, gas network expansion, upstream and downstream capex.",
     "Crude price volatility, government pricing policy, energy-transition risk."),
    ("Logistics and transport", .10, .06, .12, 11.0, 1.3, 24, 1.00,
     "GST-led consolidation, e-commerce and warehousing demand, infrastructure improvement.",
     "Fuel costs, fragmented competition, asset intensity, driver and fleet availability."),
    ("Hospitality and travel", .11, .06, .28, 15.0, 4.0, 30, 1.15,
     "Domestic and inbound tourism growth, branded hotel supply gap, events and leisure demand.",
     "Cyclical and seasonal demand, high fixed costs, pandemic or geopolitical shocks, supply additions."),
    ("Education and training", .10, .06, .25, 14.0, 3.5, 28, 0.90,
     "Young population, rising spend on skilling and test preparation, edtech blending with offline.",
     "Regulatory limits on fees, student acquisition cost, quality and brand dependence."),
    ("Agriculture and agri-inputs", .08, .05, .13, 10.0, 1.3, 18, 0.90,
     "Farm income growth, crop-protection and seed demand, rural credit and mechanisation.",
     "Monsoon dependence, price controls, channel credit risk, regulatory bans on products."),
    ("Media and entertainment", .09, .05, .22, 11.0, 2.4, 20, 1.05,
     "Advertising growth, digital subscriptions, regional content, live events.",
     "Advertising cyclicality, content cost inflation, platform shifts, piracy and regulation."),
    ("Telecom and digital infrastructure", .08, .05, .40, 8.0, 3.2, 18, 0.90,
     "Data consumption growth, 5G and fibre roll-out, tower and data-centre demand.",
     "High capital intensity and leverage, tariff pressure, spectrum costs, regulatory changes."),
    ("Packaging and paper", .08, .05, .15, 9.0, 1.3, 17, 0.95,
     "E-commerce and FMCG packaging demand, shift from plastic, export opportunities.",
     "Pulp and resin price swings, environmental rules, customer concentration, energy costs."),
    ("Consumer durables", .10, .06, .09, 16.0, 1.4, 32, 1.00,
     "Rising ownership of appliances, premiumisation, replacement cycles, strong channel presence.",
     "Commodity and import costs, competition, discounting, seasonality."),
    ("Jewellery and gems", .09, .05, .08, 12.0, 0.9, 20, 1.00,
     "Wedding and festival demand, shift to organised and hallmarked jewellery, exports.",
     "Gold price volatility, import duty changes, inventory financing, regulatory compliance."),
    ("Defence and aerospace", .14, .08, .20, 20.0, 3.5, 40, 1.10,
     "Indigenisation policy, rising defence budgets, export orders, long-term order books.",
     "Government order timing, long cycles, technology and certification risk, working capital."),
]

# Industries where EBITDA and FCFF-based methods are not suitable. Weights are suggested only.
_SPECIAL = [
    ("Banking / NBFC / financial services", .12, .08, .30, 0.0, 0.0, 14, 1.10,
     "Credit growth, financialisation of savings, digital lending, rising formal credit penetration.",
     "Asset quality, funding cost and liquidity, regulatory capital and RBI norms, interest-rate cycle.",
     "EV/EBITDA and free-cash-flow DCF are not suitable for lending businesses because debt is the raw "
     "material, not a financing choice. Value on equity-based measures (price to book, price to earnings, "
     "dividend discount or excess-return models) and adjusted net assets. This tool gives P/E and NAV "
     "weight by default. Add a book-value-based cross-check separately.",
     {"dcf": 0, "ev_ebitda": 0, "pe": 50, "nav": 50}),
    ("Investment / holding company", .10, .06, .20, 0.0, 0.0, 12, 1.00,
     "Value of underlying investments, dividend and interest inflows, appreciation of holdings.",
     "Concentration in few holdings, illiquid or unlisted investments, holding-company discount, valuation date effect.",
     "A holding company is usually valued on a sum-of-the-parts basis: fair value of each investment "
     "less holding-company debt and costs, often with a holding-company discount. This tool gives "
     "adjusted net assets the highest weight by default. Prepare the sum-of-the-parts separately and enter "
     "the result as adjusted net assets.",
     {"dcf": 0, "ev_ebitda": 0, "pe": 20, "nav": 80}),
]

_CUSTOM = ("Custom (enter your own)", .10, .06, .15, 10.0, 1.5, 20, 1.00,
           "[Describe the demand drivers of the industry.]",
           "[Describe the key risks of the industry.]")


def build_defaults():
    out = {}
    for r in _ROWS:
        name, cg, lg, mg, eve, evs, pe, beta, drv, rsk = r
        out[name] = dict(current_growth=cg, long_term_growth=lg, target_margin=mg, ev_ebitda=eve,
                         ev_sales=evs, pe=pe, beta=beta, source=PLACEHOLDER, as_of="",
                         drivers=drv, risks=rsk, method_note="", suggested_weights=None)
    for r in _SPECIAL:
        name, cg, lg, mg, eve, evs, pe, beta, drv, rsk, note, sw = r
        out[name] = dict(current_growth=cg, long_term_growth=lg, target_margin=mg, ev_ebitda=eve,
                         ev_sales=evs, pe=pe, beta=beta, source=PLACEHOLDER, as_of="",
                         drivers=drv, risks=rsk, method_note=note, suggested_weights=sw)
    name, cg, lg, mg, eve, evs, pe, beta, drv, rsk = _CUSTOM
    out[name] = dict(current_growth=cg, long_term_growth=lg, target_margin=mg, ev_ebitda=eve,
                     ev_sales=evs, pe=pe, beta=beta, source="user entered", as_of="",
                     drivers=drv, risks=rsk, method_note="", suggested_weights=None)
    return out


def merge_with_saved(saved):
    """Keep everything the user saved. Add industries that are new in this version, and fill in
    fields that older saved entries do not have yet. Custom stays last."""
    defaults = build_defaults()
    merged = {}
    custom_key = _CUSTOM[0]
    for name, d in defaults.items():
        if name == custom_key:
            continue
        if name in saved:
            entry = dict(saved[name])
            for k, v in d.items():
                entry.setdefault(k, v)
            merged[name] = entry
        else:
            merged[name] = d
    for name, d in saved.items():          # the user's own industries
        if name not in defaults:
            entry = dict(d)
            for k, v in defaults[custom_key].items():
                entry.setdefault(k, v if k not in ("drivers", "risks") else "")
            merged[name] = entry
    merged[custom_key] = dict(defaults[custom_key], **saved.get(custom_key, {}))
    for k, v in defaults[custom_key].items():
        merged[custom_key].setdefault(k, v)
    return merged
