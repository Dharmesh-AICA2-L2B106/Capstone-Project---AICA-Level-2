@echo off
setlocal
cd /d "%~dp0"
title ValuationPilot

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)
if not defined PY (
  echo.
  echo  Python is not installed on this PC.
  echo  Install Python 3.10 or newer from https://www.python.org/downloads/
  echo  and tick the box "Add python.exe to PATH" during installation.
  echo  Then double-click this file again.
  echo.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\pythonw.exe" (
  echo  First run: setting up ValuationPilot. This needs internet once and takes about a minute...
  %PY% -m venv .venv
  if errorlevel 1 (
    echo  Could not create the Python environment.
    pause
    exit /b 1
  )
)

if not exist ".venv\installed_v3.flag" (
  echo  Installing or updating the packages ValuationPilot needs...
  ".venv\Scripts\python.exe" -m pip install --disable-pip-version-check -r requirements.txt
  if errorlevel 1 (
    echo.
    echo  Could not install the required packages. Check your internet connection and try again.
    pause
    exit /b 1
  )
  echo ok> ".venv\installed_v3.flag"
)

rem Start the app in its own window (no black console window) and close this one
start "" ".venv\Scripts\pythonw.exe" app.py
exit /b 0
