"""
ValuationPilot - local desktop app.
Start it with Start_ValuationPilot.bat. It opens in your browser at http://localhost:8000
All calculations happen in Python on this PC. Nothing is sent anywhere.
"""
import os
import sys
import json
import re
import socket
import threading
import webbrowser
from datetime import date

from flask import Flask, request, jsonify, render_template, send_from_directory

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
LOG_FILE = os.path.join(HERE, "valuationpilot.log")
if sys.stdout is None or sys.stderr is None:      # started with pythonw: no console, so log to a file
    try:
        _log = open(LOG_FILE, "a", buffering=1, encoding="utf-8")
        sys.stdout = sys.stdout or _log
        sys.stderr = sys.stderr or _log
    except Exception:
        pass
from valuation_engine import (Company, Industry, YearPlan, build_projection, wacc, dcf, comparables,
                              blend, sensitivity, sensitivity_exit)
from industries_data import build_defaults, merge_with_saved
import report_text as RT
from report_gen import build_word, build_excel

OUT = os.path.join(HERE, "output")
CASES = os.path.join(HERE, "cases")
os.makedirs(OUT, exist_ok=True)
os.makedirs(CASES, exist_ok=True)
app = Flask(__name__, template_folder=os.path.join(HERE, "templates"))
app.json.sort_keys = False      # keep industries in the order saved (the first one is the default)

INDUSTRIES_FILE = os.path.join(HERE, "industries.json")


def load_industries():
    saved = {}
    if os.path.exists(INDUSTRIES_FILE):
        try:
            with open(INDUSTRIES_FILE, encoding="utf-8") as f:
                saved = json.load(f)
        except Exception:
            saved = {}
    merged = merge_with_saved(saved) if saved else build_defaults()
    with open(INDUSTRIES_FILE, "w", encoding="utf-8") as f:
        json.dump(merged, f, indent=2)
    return merged


def num(d, k, default=0.0):
    v = d.get(k, default)
    if v in ("", None):
        return default
    return float(v)


def fmt_in(x):
    """Indian digit grouping, for example 12,34,567."""
    n = int(round(abs(x)))
    s = str(n)
    if len(s) > 3:
        head, tail = s[:-3], s[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:]); head = head[:-2]
        if head:
            parts.insert(0, head)
        s = ",".join(parts) + "," + tail
    return ("-" if x < 0 and n else "") + s


# ----------------------------------------------------------------------------------------------
# Calculation
# ----------------------------------------------------------------------------------------------
def valuate(c, ind, plan, premium, speed, wi, g, em, disc, dlom, wt_in,
            growth_adj=0.0, margin_adj=0.0, wacc_adj=0.0):
    rows = build_projection(c, ind, plan, company_premium=premium, margin_speed=speed,
                            growth_adj=growth_adj, margin_adj=margin_adj)
    w, ke, kd = wacc(wi["rf"], wi["erp"], wi["beta"], wi["size"], wi["spec"], wi["kd_pre"], c.tax_rate, wi["dw"])
    w_use = w + wacc_adj
    dres = dcf(rows, w_use, g, em, c, dlom=dlom)
    comp = comparables(c, ind, disc)
    vals = {"dcf": (dres["gordon"]["equity"] + dres["exit_multiple"]["equity"]) / 2,
            "ev_ebitda": comp["ev_ebitda"], "nav": c.adjusted_net_assets}
    if "pe" in comp:
        vals["pe"] = comp["pe"]
    raw = {k: float(wt_in.get(k, 0) or 0) for k in vals}
    if sum(raw.values()) <= 0:
        raw = {k: 1.0 for k in vals}
    tw = sum(raw.values())
    wts = {k: v / tw for k, v in raw.items()}
    blended = blend(vals, raw)
    return dict(rows=rows, w=w, w_use=w_use, ke=ke, kd=kd, dres=dres, comp=comp, vals=vals, wts=wts,
                raw_weight_total=sum(float(wt_in.get(k, 0) or 0) for k in vals), blended=blended)


def run_valuation(d):
    c = Company(d.get("company_name") or "Company", num(d, "base_revenue"), num(d, "base_margin"),
                tax_rate=num(d, "tax_rate", 0.25), dep_pct_sales=num(d, "dep_pct", 0.03),
                capex_pct_sales=num(d, "capex_pct", 0.05), nwc_pct_sales=num(d, "nwc_pct", 0.15),
                debt=num(d, "debt"), cash=num(d, "cash"), shares=num(d, "shares", 1) or 1,
                base_net_profit=num(d, "net_profit", 0) or None, adjusted_net_assets=num(d, "nav"))
    if c.base_revenue <= 0:
        raise ValueError("Base year revenue must be greater than zero.")
    ind = Industry(d.get("industry_name") or "Industry", num(d, "ind_current"), num(d, "ind_longterm"),
                   num(d, "ind_margin"), num(d, "ind_evebitda"), num(d, "ind_evsales"), num(d, "ind_pe"),
                   d.get("ind_source", ""), d.get("ind_asof", ""))
    plan, plan_basis = [], []
    for y in d.get("plan", []):
        mode = y.get("mode", "auto")
        g_, m_ = y.get("growth"), y.get("margin")
        g_ = None if g_ in ("", None) else float(g_)
        m_ = None if m_ in ("", None) else float(m_)
        plan.append(YearPlan(mode, g_ if mode == "manual" else None, m_ if mode == "manual" else None))
        plan_basis.append((y.get("basis") or "").strip())
    while len(plan) < 5:
        plan.append(YearPlan()); plan_basis.append("")
    premium, speed = num(d, "premium"), num(d, "margin_speed", 0.5)
    wi = dict(rf=num(d, "rf"), erp=num(d, "erp"), beta=num(d, "beta", 1), size=num(d, "size_prem"),
              spec=num(d, "spec_prem"), kd_pre=num(d, "kd_pre"), dw=num(d, "debt_weight"))
    g, em, disc, dlom = num(d, "term_g"), num(d, "exit_mult"), num(d, "comp_discount"), num(d, "dlom")
    w_base = wacc(wi["rf"], wi["erp"], wi["beta"], wi["size"], wi["spec"], wi["kd_pre"], c.tax_rate, wi["dw"])[0]
    if w_base <= g + 0.0201:
        raise ValueError("WACC must be at least 2 percentage points higher than terminal growth "
                         "(the sensitivity table moves both by 1 point). Lower terminal growth or raise the discount rate.")
    wt_in = d.get("weights", {})
    base = valuate(c, ind, plan, premium, speed, wi, g, em, disc, dlom, wt_in)

    # Scenarios: the DCF moves, the market and asset methods stay as they are.
    sg, sm, sw = num(d, "scen_growth", 0.02), num(d, "scen_margin", 0.015), num(d, "scen_wacc", 0.01)
    scenarios = []
    for label, ga, ma, wa in (("Best case", sg, sm, -sw), ("Base case", 0, 0, 0), ("Worst case", -sg, -sm, sw)):
        if label == "Base case":
            s = base
        elif base["w"] + wa <= g + 0.005:
            scenarios.append(dict(label=label, growth_adj=ga, margin_adj=ma, wacc_adj=wa, skipped=True))
            continue
        else:
            s = valuate(c, ind, plan, premium, speed, wi, g, em, disc, dlom, wt_in, ga, ma, wa)
        scenarios.append(dict(label=label, growth_adj=ga, margin_adj=ma, wacc_adj=wa, skipped=False,
                              wacc=s["w_use"], revenue5=s["rows"][-1]["revenue"], ebitda5=s["rows"][-1]["ebitda"],
                              dcf=s["vals"]["dcf"], blended=s["blended"]))

    w = base["w"]
    grid = sensitivity(base["rows"], c, [w - 0.01, w, w + 0.01], [g - 0.01, g, g + 0.01], em, dlom=dlom)
    mults = [max(em - 1.0, 0.5), em, em + 1.0]
    grid_exit = sensitivity_exit(base["rows"], c, [w - 0.01, w, w + 0.01], mults, g, dlom=dlom)

    r = dict(c=c, ind=ind, plan=plan, plan_basis=plan_basis, rows=base["rows"], wi=wi, w=w, ke=base["ke"],
             kd=base["kd"], g=g, em=em, disc=disc, dlom=dlom, premium=premium, speed=speed,
             dres=base["dres"], comp=base["comp"], vals=base["vals"], wts=base["wts"],
             raw_weight_total=base["raw_weight_total"], blended=base["blended"], grid=grid,
             grid_exit=grid_exit, scenarios=scenarios, ind_note=d.get("ind_note", ""))
    r["checks"] = make_checks(r, d)
    r["implied"] = implied(r)
    return r


def implied(r):
    c, ev_g, ev_x = r["c"], r["dres"]["gordon"]["ev"], r["dres"]["exit_multiple"]["ev"]
    base_ebitda = c.base_revenue * c.base_ebitda_margin
    out = dict(ev_ebitda_gordon=ev_g / base_ebitda if base_ebitda else None,
               ev_ebitda_exit=ev_x / base_ebitda if base_ebitda else None,
               tv_share_gordon=(r["dres"]["gordon"]["tv"] / (1 + r["w"]) ** 4.5) / ev_g if ev_g else None,
               tv_share_exit=(r["dres"]["exit_multiple"]["tv"] / (1 + r["w"]) ** 5) / ev_x if ev_x else None,
               pe_dcf=(r["vals"]["dcf"] / c.base_net_profit) if c.base_net_profit else None)
    return out


def make_checks(r, d):
    c, ind, out = r["c"], r["ind"], []
    imp = implied(r)
    add = lambda level, text: out.append(dict(level=level, text=text))

    if "PLACEHOLDER" in (ind.source or "").upper() or not (ind.source or "").strip():
        add("warn", "The industry figures are placeholders or have no source. Replace them with sourced data and record the source and date on the Industry tab.")
    if r["ind_note"]:
        add("info", "Method note for this industry: " + r["ind_note"])
    for key, label in (("tv_share_gordon", "Gordon growth"), ("tv_share_exit", "exit multiple")):
        v = imp.get(key)
        if v is not None and v > 0.75:
            add("warn", f"Terminal value is {v*100:.0f}% of the DCF enterprise value ({label}). The result depends heavily on long-term assumptions.")
    gq, xq = r["dres"]["gordon"]["equity"], r["dres"]["exit_multiple"]["equity"]
    if gq > 0 and xq > 0 and max(gq, xq) / min(gq, xq) > 1.5:
        add("warn", f"The Gordon growth DCF ({fmt_in(gq)}) and exit multiple DCF ({fmt_in(xq)}) differ by more than 50%. Revisit the terminal growth rate or the exit multiple.")
    if r["g"] > ind.long_term_growth + 1e-9:
        add("warn", "Terminal growth is higher than the long-term growth of the industry.")
    if r["g"] > r["wi"]["rf"] + 1e-9:
        add("warn", "Terminal growth is higher than the risk-free rate, which is hard to defend for a perpetual rate.")
    vals = [v for v in r["vals"].values()]
    if min(vals) > 0 and max(vals) / min(vals) > 3:
        add("warn", "The methods give very different values (the highest is more than three times the lowest). The weights drive the conclusion, so record the reason for each weight.")
    base_ebitda = c.base_revenue * c.base_ebitda_margin
    if base_ebitda > 0 and (c.debt - c.cash) > 3 * base_ebitda:
        add("warn", "Net debt is more than three times base-year EBITDA. Check the debt weight in WACC and refinancing risk.")
    neg = [str(x["year"]) for x in r["rows"] if x["fcff"] < 0]
    if neg:
        add("warn", "Free cash flow is negative in year(s) " + ", ".join(neg) + ". Check capex and working capital assumptions.")
    if r["blended"] <= 0:
        add("warn", "The blended equity value is zero or negative.")
    ev_ind = ind.ev_ebitda
    if ev_ind and imp["ev_ebitda_gordon"] and abs(imp["ev_ebitda_gordon"] / ev_ind - 1) > 0.4:
        add("info", f"The DCF implies an EV/EBITDA of {imp['ev_ebitda_gordon']:.1f}x (Gordon growth), compared with {ev_ind:.1f}x for the industry.")
    if "pe" not in r["vals"] and float((d.get("weights") or {}).get("pe", 0) or 0) > 0:
        add("warn", "A weight is set for P/E but no base-year net profit was entered, so P/E is left out of the blend.")
    tot = r["raw_weight_total"]
    if tot > 0 and abs(tot - 100) > 0.01:
        add("info", f"The method weights add up to {tot:.0f}. They have been scaled to 100%.")
    for i, (p, b) in enumerate(zip(r["plan"], r["plan_basis"]), 1):
        if p.mode == "manual" and not b:
            add("warn", f"Year {i} uses a manual figure but no reason is recorded. Add the reason on the Growth plan tab.")
    return out


def to_json(r):
    return dict(
        wacc=r["w"], cost_equity=r["ke"], cost_debt=r["kd"], rows=r["rows"], dcf=r["dres"],
        comp=r["comp"], nav=r["c"].adjusted_net_assets, vals=r["vals"], weights=r["wts"],
        blended=r["blended"], per_share=r["blended"] / r["c"].shares,
        low=min(r["vals"].values()), high=max(r["vals"].values()),
        sens=[dict(wacc=k[0], g=k[1], value=v) for k, v in r["grid"].items()],
        sens_exit=[dict(wacc=k[0], mult=k[1], value=v) for k, v in r["grid_exit"].items()],
        scenarios=r["scenarios"], checks=r["checks"], implied=r["implied"])


# ----------------------------------------------------------------------------------------------
# Report text
# ----------------------------------------------------------------------------------------------
def make_meta(d, r):
    def f(k, dflt=""):
        v = d.get(k)
        return v.strip() if isinstance(v, str) and v.strip() else dflt
    ind = r["ind"]
    standard = f("standard", "Fair value")
    ctx = dict(company=r["c"].name, client=f("client", "[Client name]"),
               firm=f("firm", "[Firm name], Chartered Accountants"), industry=ind.name,
               val_date=f("val_date", "[Valuation date]"),
               report_date=f("report_date", date.today().strftime("%d %B %Y")),
               purpose=f("purpose", "[Purpose of valuation]"), standard=standard, standard_lc=standard.lower(),
               unit=f("unit", "lakh"), dlom_pct=(f"{r['dlom']*100:.1f}%" if r["dlom"] > 0 else "none applied"),
               ind_source=((ind.source or "[source]") + (" (" + ind.as_of + ")" if ind.as_of else "")))
    fill = lambda key, default: RT.fill(f(key, default), ctx)
    to_lines = lambda txt: [ln.strip() for ln in txt.splitlines() if ln.strip()]
    basis = {k: RT.fill(((d.get("basis_" + k) or "").strip() or v), ctx) for k, v in RT.BASIS.items()}
    return dict(
        firm=ctx["firm"], client=ctx["client"], val_date=ctx["val_date"], report_date=ctx["report_date"],
        purpose=ctx["purpose"], standard=standard, unit=ctx["unit"], draft=bool(d.get("draft", True)),
        g=r["g"], exit_mult=r["em"], comp_discount=r["disc"], dlom=r["dlom"], premium=r["premium"],
        margin_speed=r["speed"], weights=r["wts"],
        engagement=fill("engagement", RT.ENGAGEMENT), scope=fill("scope", RT.SCOPE),
        sources=fill("sources", RT.SOURCES),
        limitations=to_lines(fill("limitations", RT.LIMITATIONS)),
        declarations=to_lines(fill("declarations", RT.DECLARATIONS)),
        certificate_text=fill("certificate", RT.CERTIFICATE), basis=basis,
        ind_basis_note=f("ind_basis", ""),
        ca_name=f("ca_name", "CA [Name]"), membership_no=f("membership_no", "[Membership No.]"),
        firm_reg=f("firm_reg", "[Firm name / FRN]"), rv_no=f("rv_no", "[If applicable]"),
        udin=f("udin", "[UDIN]"), place_date=f("place_date", "[Place], [Date]"),
        ind_drivers=f("ind_drivers", ""), ind_risks=f("ind_risks", ""), ind_note=f("ind_note", ""))


# ----------------------------------------------------------------------------------------------
# Routes
# ----------------------------------------------------------------------------------------------
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/industries")
def api_industries():
    return jsonify(load_industries())


@app.route("/api/industries", methods=["POST"])
def api_save_industries():
    with open(INDUSTRIES_FILE, "w", encoding="utf-8") as f:
        json.dump(request.get_json(), f, indent=2)
    return jsonify(ok=True)


@app.route("/api/defaults")
def api_defaults():
    return jsonify(RT.defaults_payload())


def case_path(name):
    safe = re.sub(r"[^A-Za-z0-9 _\-]", "", name or "").strip().replace(" ", "_")
    if not safe:
        raise ValueError("Give the case a name (the company name is used).")
    return safe, os.path.join(CASES, safe + ".json")


@app.route("/api/cases")
def api_cases():
    names = sorted(os.path.splitext(f)[0] for f in os.listdir(CASES) if f.endswith(".json"))
    return jsonify(names)


@app.route("/api/cases", methods=["POST"])
def api_save_case():
    try:
        body = request.get_json()
        safe, path = case_path(body.get("name"))
        with open(path, "w", encoding="utf-8") as f:
            json.dump(body.get("data", {}), f, indent=2)
        return jsonify(ok=True, name=safe)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400


@app.route("/api/cases/<name>")
def api_load_case(name):
    try:
        _, path = case_path(name)
        with open(path, encoding="utf-8") as f:
            return jsonify(ok=True, data=json.load(f))
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400


@app.route("/api/run", methods=["POST"])
def api_run():
    try:
        return jsonify(ok=True, **to_json(run_valuation(request.get_json())))
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400


@app.route("/api/report", methods=["POST"])
def api_report():
    try:
        d = request.get_json()
        r = run_valuation(d)
        meta = make_meta(d, r)
        safe = "".join(ch for ch in r["c"].name if ch.isalnum() or ch in " _-").strip().replace(" ", "_") or "Company"
        wpath = os.path.join(OUT, f"Valuation_Report_{safe}.docx")
        xpath = os.path.join(OUT, f"Valuation_Workbook_{safe}.xlsx")
        build_word(wpath, r, meta)
        build_excel(xpath, r["c"], r["ind"], r["plan"], r["wi"], meta)
        return jsonify(ok=True, word=os.path.basename(wpath), excel=os.path.basename(xpath))
    except PermissionError:
        return jsonify(ok=False, error="Could not save the files. Close the Word or Excel file if it is open, then try again."), 400
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400


@app.route("/favicon.ico")
def favicon():
    return send_from_directory(HERE, "valuationpilot.ico")


@app.route("/download/<path:name>")
def download(name):
    return send_from_directory(OUT, name, as_attachment=True)


@app.route("/api/open", methods=["POST"])
def api_open():
    """Open a generated file (Word or Excel) with the program installed on this PC."""
    try:
        name = os.path.basename((request.get_json() or {}).get("name", ""))
        path = os.path.join(OUT, name)
        if not name or not os.path.isfile(path):
            raise ValueError("That file was not found in the output folder. Generate the report again.")
        open_path(path)
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400


@app.route("/api/openfolder", methods=["POST"])
def api_open_folder():
    try:
        open_path(OUT)
        return jsonify(ok=True)
    except Exception as e:
        return jsonify(ok=False, error=str(e)), 400


@app.route("/api/quit", methods=["POST"])
def api_quit():
    threading.Timer(0.4, lambda: os._exit(0)).start()
    return jsonify(ok=True)


def open_path(path):
    if hasattr(os, "startfile"):
        os.startfile(path)                      # Windows: opens with the default program
    else:
        import subprocess
        subprocess.Popen(["xdg-open", path])


# ----------------------------------------------------------------------------------------------
# Start-up: a real application window, not a browser tab
# ----------------------------------------------------------------------------------------------
def free_port(start=8000):
    for p in range(start, start + 20):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex(("127.0.0.1", p)) != 0:
                return p
    return start


def error_box(title, text):
    try:
        import ctypes
        ctypes.windll.user32.MessageBoxW(0, text, title, 0x10)
    except Exception:
        print(title + ": " + text)


ICON_FILE = os.path.join(HERE, "valuationpilot.ico")
TITLE = "ValuationPilot"


def run_native_window(url):
    """Show the app in its own window using the Windows WebView2 control (through pywebview).
    Returns True if the window was shown and then closed."""
    try:
        import webview
    except Exception as e:
        print("pywebview is not installed:", e)
        return False
    try:
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("ValuationPilot.App")
        except Exception:
            pass
        window = webview.create_window(TITLE, url, width=1320, height=880, min_size=(1000, 640),
                                       text_select=True)

        def after_start():
            # give the window and taskbar button our icon (the window needs a moment to exist)
            import time
            for _ in range(40):
                try:
                    native = window.native
                    if native is not None:
                        import ctypes
                        user32 = ctypes.windll.user32
                        hicon = user32.LoadImageW(None, ICON_FILE, 1, 0, 0, 0x10)
                        hwnd = int(native.Handle.ToInt64())
                        user32.SendMessageW(hwnd, 0x80, 1, hicon)   # WM_SETICON, big
                        user32.SendMessageW(hwnd, 0x80, 0, hicon)   # small
                        return
                except Exception as e:
                    last = e
                time.sleep(0.25)
            print("could not set window icon")

        webview.start(after_start)
        return True
    except Exception as e:
        print("could not open the native window:", e)
        return False


def find_app_browser():
    """Edge or Chrome, used in 'app mode' (no tabs, no address bar) if the native window is unavailable."""
    roots = [os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles"), os.environ.get("LocalAppData")]
    rel = [r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe"]
    for r in rel:
        for root in roots:
            if root and os.path.isfile(os.path.join(root, r)):
                return os.path.join(root, r)
    return None


def run_app_mode_window(url):
    exe = find_app_browser()
    if not exe:
        return False
    try:
        import subprocess
        profile = os.path.join(HERE, ".appwindow")        # its own profile, so we can tell when the window closes
        proc = subprocess.Popen([exe, f"--app={url}", f"--user-data-dir={profile}", "--window-size=1320,880",
                                 "--no-first-run", "--no-default-browser-check"])
        proc.wait()
        return True
    except Exception as e:
        print("could not open the app-mode window:", e)
        return False


def main():
    from werkzeug.serving import make_server
    load_industries()
    port = free_port()
    url = f"http://127.0.0.1:{port}"
    server = make_server("127.0.0.1", port, app, threaded=True)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    print(f"ValuationPilot is running at {url}")
    if os.environ.get("VP_NO_WINDOW") == "1":           # used for testing only
        thread.join()
        return
    if run_native_window(url) or run_app_mode_window(url):
        server.shutdown()
        return
    # last resort: a browser tab. The Exit button inside the app stops the program.
    webbrowser.open(url)
    error_box(TITLE, "ValuationPilot could not open its own window, so it was opened in your browser.\n\n"
                     "Use the Exit button in the app to close it.\n\nDetails are in valuationpilot.log.")
    thread.join()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        import traceback
        traceback.print_exc()
        error_box(TITLE, "ValuationPilot could not start.\n\nDetails are in valuationpilot.log in the app folder.")
