"""
ValuationPilot - standard report wording.

Everything here is a TEMPLATE. The valuer edits it in the app (Report tab and the basis boxes on the
Valuation tab). Words in {curly braces} are filled automatically when the report is generated, and
[square brackets] are left for the valuer to complete by hand. Check the wording against the
requirements that apply to your purpose (law, regulator, engagement letter, ICAI standards) before signing.
"""
import re

TOKENS_HELP = ("{company} {client} {firm} {industry} {val_date} {report_date} {purpose} {standard} "
               "{standard_lc} {unit} {dlom_pct} {ind_source}")

PURPOSES = [
    "Issue or transfer of shares of a private company",
    "Fund raising or investment by a new investor",
    "Internal use by the management of the Company",
    "Merger, demerger or other restructuring",
    "Employee stock option plan (ESOP)",
    "Lending, security or credit assessment",
    "Dispute, settlement or exit of a shareholder",
    "Other (type the purpose)",
]

ENGAGEMENT = """# Engagement
- {firm} ("we", "us") has been engaged by {client} (the "Client") to estimate the {standard_lc} of the equity shares of {company} (the "Company") as at {val_date} (the "Valuation Date").
- Purpose of the valuation: {purpose}.
- This report is addressed to the Client and has been prepared only for the purpose stated above. [Add engagement letter reference and date, if any.]
- The valuation has been carried out in accordance with the ICAI Valuation Standards to the extent applicable. [Confirm the standard and edition, and any law or regulation that prescribes the method or the valuer for this purpose.]
- Report date: {report_date}."""

SCOPE = """# Scope and basis of value
- Standard of value: {standard}. Premise of value: going concern, that is, the Company is assumed to continue its business for the foreseeable future.
- Level of value: [state whether controlling or minority interest, and marketable or non-marketable]. Discount for lack of marketability applied: {dlom_pct}.
- Approaches considered: income approach (discounted cash flow, with Gordon growth and exit multiple terminal values), market approach (EV/EBITDA, EV/Sales and P/E multiples of the {industry} industry) and asset approach (adjusted net asset value). The conclusion is a weighted blend of the methods. The weights and the reasons for them are in the section on reconciliation.
- Projection period: five years from the base year. Growth and margin assumptions for each year, with their basis, are in the section on projections.
- Currency and unit: Indian Rupees (INR). Amounts are in {unit} unless stated otherwise.
- This engagement is not an audit, review or due diligence. We have not independently verified the information given to us, and we express no opinion on legal title, taxation or regulatory matters.
- Events after the Valuation Date up to the report date [have / have not] been considered. [Describe, if any.]"""

SOURCES = """# Sources of information
- Financial statements of the Company for [financial years], [audited / unaudited].
- Projections or business plan provided by the management of the Company, dated [date].
- Industry data for the {industry} industry: {ind_source}.
- Market data (risk-free rate, equity risk premium, beta, cost of debt): [source and date].
- Multiples of comparable companies: [source, names of companies, date].
- Fair value of assets and liabilities used for adjusted net assets: [source, valuer and date], if any.
- Management representation letter dated [date].
- Discussions with the management of the Company on [dates].
- Other: [describe]."""

LIMITATIONS = """Projections are based on the stated assumptions. They are not forecasts or guarantees of future performance.
Information supplied by the management of the Company has been relied upon without independent audit or verification, unless stated.
Industry and market data come from the sources and dates listed and should be refreshed before the report is relied upon.
The conclusion is valid only for the stated purpose, valuation date and standard of value. It should not be used for any other purpose or date.
Valuation involves judgement. Another valuer could reach a different conclusion. The result is a point estimate within the range shown in this report.
This report should not be copied or shared with other parties without our written consent, unless the law requires it."""

DECLARATIONS = """We have no present or planned financial interest in the Company or the Client beyond our professional fee, and the fee does not depend on the conclusion of value.
We have no personal interest in, or bias toward, the subject of this report or the parties involved.
[Add any other declaration, disclosure or independence statement required for this purpose, for example registered valuer details or conflict-of-interest disclosures.]"""

CERTIFICATE = ("I/We have reviewed the valuation set out in this report, including the assumptions, methods and "
               "calculations, and, based on the information provided and the analysis performed, certify the "
               "conclusion of value stated in Section 1 as at the valuation date.")

# Basis wording for each assumption. Valuer edits these on the Valuation tab.
BASIS = {
    "base_margin": "Actual EBITDA margin of the Company for the base year as per its financial statements. [Add year and any normalisation.]",
    "tax": "Tax rate applicable to the Company under its tax regime. [Confirm regime and rate.]",
    "dep": "Depreciation as a share of sales, based on the Company's recent history. [Add years used.]",
    "capex": "Capital expenditure as a share of sales, based on the Company's history and growth plan. [Add years used.]",
    "nwc": "Net working capital as a share of sales, based on the Company's recent balance sheets. [Add years used.]",
    "rf": "Yield on the 10-year Government of India security as on the Valuation Date. [Insert yield and source.]",
    "erp": "Equity risk premium for the Indian market. [Insert figure and source, for example a published study or house view.]",
    "beta": "Beta of comparable listed companies, re-levered for the Company's capital structure. [Insert source and date.]",
    "size": "Premium for the Company's small size compared with the listed companies used for beta and multiples. [Explain.]",
    "spec": "Premium for risks specific to the Company, such as customer concentration or dependence on key people. [Explain.]",
    "kd": "Borrowing rate of the Company, supported by its latest sanction letters or loan statements. [Insert rate and source.]",
    "dw": "Debt as a share of total capital: [target or industry structure / actual structure of the Company]. [Explain.]",
    "term_g": "Long-term growth after Year 5, kept in line with the long-term growth of the industry and not above the long-term growth of the economy. [Explain.]",
    "exit_mult": "EV/EBITDA multiple expected at the end of Year 5, based on the multiples of comparable companies, moderated for maturity. [Explain.]",
    "comp_discount": "Discount to listed-peer multiples for the Company's smaller size and lower liquidity. [Explain.]",
    "dlom": "Discount for lack of marketability, where the shares are not freely tradable. [Explain, or state that none is applied.]",
    "weights": "Greater weight is given to the methods that rely most on the Company's own cash flows and the least on judgement about peers. [Explain the reason for each weight.]",
    "nav": "Net assets of the Company adjusted to the fair value of assets and liabilities at the Valuation Date. [Add source of the adjustments.]",
}

BASIS_LABELS = {
    "base_margin": "Base EBITDA margin", "tax": "Tax rate", "dep": "Depreciation % of sales",
    "capex": "Capex % of sales", "nwc": "Net working capital % of sales", "rf": "Risk-free rate",
    "erp": "Equity risk premium", "beta": "Beta", "size": "Size premium",
    "spec": "Company-specific premium", "kd": "Cost of debt", "dw": "Debt weight in WACC",
    "term_g": "Terminal growth rate", "exit_mult": "Exit multiple", "comp_discount": "Discount on comparables",
    "dlom": "Discount for lack of marketability", "weights": "Method weights", "nav": "Adjusted net assets",
}


def fill(text, ctx):
    """Replace {token} with ctx values. Unknown tokens are left as they are."""
    if not text:
        return ""
    return re.sub(r"\{(\w+)\}", lambda m: str(ctx.get(m.group(1), m.group(0))), text)


def defaults_payload():
    return dict(engagement=ENGAGEMENT, scope=SCOPE, sources=SOURCES, limitations=LIMITATIONS,
                declarations=DECLARATIONS, certificate=CERTIFICATE, basis=BASIS, basis_labels=BASIS_LABELS,
                purposes=PURPOSES, tokens=TOKENS_HELP)
