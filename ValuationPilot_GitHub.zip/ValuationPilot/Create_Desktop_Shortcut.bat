@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$d=[Environment]::GetFolderPath('Desktop'); $s=(New-Object -ComObject WScript.Shell).CreateShortcut($d+'\ValuationPilot.lnk'); $s.TargetPath='%~dp0Start_ValuationPilot.bat'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%~dp0valuationpilot.ico'; $s.WindowStyle=7; $s.Description='ValuationPilot'; $s.Save()"
if errorlevel 1 (
  echo  Could not create the shortcut.
) else (
  echo  A ValuationPilot shortcut with its icon is now on your Desktop.
  echo  You can also right-click it and choose Pin to taskbar.
)
echo.
pause
