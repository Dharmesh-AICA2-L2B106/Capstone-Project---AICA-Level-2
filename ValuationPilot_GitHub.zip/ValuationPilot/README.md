# ValuationPilot

A Windows desktop tool for business valuation in a Chartered Accountant's practice. It runs as its own application window on the local PC (no browser, no cloud, no data leaves the machine).

**Features:** industry-linked five-year growth plan (Auto or Manual per year), WACC, DCF (Gordon growth and exit multiple), comparables, net asset value, blending of methods, sensitivity tables, best/base/worst scenarios, reasonableness checks, a print-ready Word report with a CA signing page, and an Excel workbook with live formulas so the figures can be edited.

**Design principle:** all arithmetic is done by Python and Excel formulas, never by an AI model.

## Run (Windows)
1. Install Python 3.10+ (tick "Add python.exe to PATH").
2. Double-click `Start_ValuationPilot.bat` (first run installs packages; internet needed once).
3. See `README.txt` for full instructions and troubleshooting.

## Important
- Built-in industry figures are **indicative placeholders**. Replace them with sourced data before relying on any output.
- Standard wording in the report is a template to be reviewed by the signing CA.
- The tool prepares the valuation; the signing Chartered Accountant is responsible for every assumption and conclusion.
