@echo off
setlocal
cd /d "%~dp0"
title ValuationPilot (debug)
echo  Starting ValuationPilot with this window open, so any error message is visible.
echo  Close this window to stop the app.
echo.
".venv\Scripts\python.exe" app.py
echo.
echo  ValuationPilot has stopped.
pause
