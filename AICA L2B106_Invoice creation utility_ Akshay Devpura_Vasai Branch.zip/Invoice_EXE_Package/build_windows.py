"""Run on Windows using the included BUILD_EXE.bat."""
import sys, subprocess
from pathlib import Path
if sys.platform != 'win32':
    raise SystemExit('Build this Windows executable on your Windows laptop.')
root = Path(__file__).resolve().parent
args = [sys.executable, '-m', 'PyInstaller', '--noconfirm', '--clean', '--onefile', '--windowed',
        '--name', 'Invoice Creation Utility', '--icon', str(root/'invoice.ico'),
        '--collect-all', 'reportlab', '--collect-all', 'openpyxl',
        '--hidden-import', 'PyQt6.QtPdf', '--hidden-import', 'PyQt6.QtPdfWidgets',
        '--hidden-import', 'PIL.Image', '--hidden-import', 'PIL.PngImagePlugin',
        '--hidden-import', 'PIL.JpegImagePlugin', '--hidden-import', 'PIL.BmpImagePlugin',
        '--distpath', str(root/'dist'), '--workpath', str(root/'build'),
        '--specpath', str(root), str(root/'Invoice_Creation_Utility.py')]
subprocess.run(args, cwd=root, check=True)
exe=root/'dist'/'Invoice Creation Utility.exe'
if not exe.is_file(): raise SystemExit('Executable was not generated. Check build_log.txt.')
print('SUCCESS: '+str(exe))
