@echo off
setlocal
cd /d "%~dp0"
title Build Invoice Creation Utility
 echo Building Invoice Creation Utility for Windows.
 echo Internet is required for the initial build. Please keep this window open.
 echo.
if exist ".invoice_build_env\Scripts\python.exe" goto install
py -3 -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
if errorlevel 1 goto try_python
py -3 -m venv ".invoice_build_env" >build_log.txt 2>&1
if errorlevel 1 goto failed
goto install
:try_python
python -c "import sys; assert sys.version_info >= (3,10)" >nul 2>&1
if errorlevel 1 goto no_python
python -m venv ".invoice_build_env" >build_log.txt 2>&1
if errorlevel 1 goto failed
:install
 echo Installing the build tools and application libraries...
".invoice_build_env\Scripts\python.exe" -m pip install --upgrade pip >>build_log.txt 2>&1
if errorlevel 1 goto failed
".invoice_build_env\Scripts\python.exe" -m pip install PyQt6 openpyxl Pillow reportlab pyinstaller >>build_log.txt 2>&1
if errorlevel 1 goto failed
 echo Creating your EXE. This can take several minutes...
".invoice_build_env\Scripts\python.exe" build_windows.py >>build_log.txt 2>&1
if errorlevel 1 goto failed
 echo.
 echo SUCCESS! Your utility is ready in the dist folder:
 echo Invoice Creation Utility.exe
 echo You can copy that EXE to your Desktop and double-click it to open.
start "" explorer.exe "%~dp0dist"
pause
exit /b 0
:no_python
 echo Python 3.10 or newer was not found.
 echo Install Python from https://www.python.org/downloads/windows/
 echo Then run this builder again. Python is needed only to build the EXE.
pause
exit /b 1
:failed
 echo.
 echo Build could not finish. Details are in build_log.txt in this folder.
 echo Share that file if you need help troubleshooting.
pause
exit /b 1
