@echo off
echo Installing build tools...
python -m pip install --upgrade pip
python -m pip install flask pyinstaller
echo Building EXE...
python -m pyinstaller --onefile --name AssignmentTrackerEOD launcher.py
echo.
echo Done. Your file is in the dist folder: dist\AssignmentTrackerEOD.exe
pause
