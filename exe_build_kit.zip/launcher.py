import os, sys, threading, webbrowser
base = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.path.dirname(os.path.abspath(__file__))
os.chdir(base)
os.environ.setdefault("DB_PATH", os.path.join(base, "eod_portal.db"))  # database is kept next to the exe
import assignment_tracker_eod_portal as m
port = int(os.environ.get("PORT", 5000))
if not os.environ.get("NO_BROWSER"):
    threading.Timer(1.5, lambda: webbrowser.open(f"http://127.0.0.1:{port}")).start()
print(f"Portal running at http://127.0.0.1:{port}  (close this window to stop)")
m.app.run(host=os.environ.get("HOST", "127.0.0.1"), port=port, debug=False)
